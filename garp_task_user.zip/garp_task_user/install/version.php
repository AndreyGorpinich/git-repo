<?php

$arModuleVersion = array(
    'VERSION' 		=> '0.0.1',
    'VERSION_DATE' 	=> '2016-30-09'
);