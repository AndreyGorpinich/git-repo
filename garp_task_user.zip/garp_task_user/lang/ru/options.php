<?php
defined('B_PROLOG_INCLUDED') and (B_PROLOG_INCLUDED === true) or die();

$MESS['option-director'] = "Постоновщик";
$MESS['option-responsible'] = "Ответственный";
$MESS['REFERENCES_OPTIONS_SAVED'] = "Настройки сохранены";
$MESS['DD_BM_BUTTON_SAVE']  = 'Сохранить';
$MESS['DD_BM_BUTTON_RESET'] = 'Сбросить';
$MESS['option-accomplice']='Cоисполнитель';
$MESS['option-observers']='Наблюдатели';
$MESS['option-name']='Название';
?>
