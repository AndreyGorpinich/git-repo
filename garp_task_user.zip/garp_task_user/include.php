<?

IncludeModuleLangFile(__FILE__);
CModule::AddAutoloadClasses(
	"garp_task_user",
	array(
		"Task_user" => "classes/general/garp_task_user.php"
		)
	);
?>